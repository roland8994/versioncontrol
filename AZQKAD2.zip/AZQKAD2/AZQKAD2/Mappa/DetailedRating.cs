﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AZQKAD2.Mappa
{
    class DetailedRating
    {
    }
}
